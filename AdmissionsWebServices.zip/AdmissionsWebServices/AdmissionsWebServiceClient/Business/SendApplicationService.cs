﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AdmissionsWebServiceClient.Client;
using AdmissionsWebServiceClient.Models;
using log4net;

namespace AdmissionsWebServiceClient.Business
{
    internal class SendApplicationService : ISendApplicationService
    {
        private static readonly ILog Log = LogManager.GetLogger(typeof(SendApplicationService));

        private readonly IWebServiceClient _webService;

        public SendApplicationService()
        {
            _webService = ClientFactory.GetDefault();
        }
        public SendApplicationService(IWebServiceClient webService)
        {
            _webService = webService;
        }

        public async Task<ICollection<Tuple<CreateApplicationRequest, CreateApplicationResponse>>> SendApplications(ICollection<CreateApplicationRequest> applications)
        {
            var results = new BlockingCollection<Tuple<CreateApplicationRequest, CreateApplicationResponse>>();
            var tasks = applications
                .AsParallel()
                .WithDegreeOfParallelism(10)
                .Select(x => TryProcessApplicationToResultCollection(x, results))
                .ToArray();

            await Task.WhenAll(tasks);

            return results.ToArray();
        }
        private async Task TryProcessApplicationToResultCollection(CreateApplicationRequest input, BlockingCollection<Tuple<CreateApplicationRequest, CreateApplicationResponse>> results)
        {
            var output = await TryProcessApplication(input);
            results.Add(new Tuple<CreateApplicationRequest, CreateApplicationResponse>(input, output));
        }
        
        public async Task<CreateApplicationResponse> SendApplication(CreateApplicationRequest input)
        {
            return await TryProcessApplication(input);
        }
        protected async Task<CreateApplicationResponse> TryProcessApplication(CreateApplicationRequest input)
        {
            try
            {
                Log.Info($"Processing application for: {input.FirstName} {input.LastName} ({input.LascAccountNum})");
                var result = await ProcessApplication(input);

                if (result.Successful)
                {
                    Log.Info($"- UID Created: {result.UniversityId}");
                    SaveAssignedUid(input, result.UniversityId);
                }

                return result;
            }
            catch (Exception e)
            {
                var processError = new LawApplicationException(e.Message, e)
                {
                    FirstName = input.FirstName,
                    LastName = input.LastName,
                    LascAccountNum = input.LascAccountNum
                };

                Log.Error(processError);
                throw processError;
            }
        }
        private async Task<CreateApplicationResponse> ProcessApplication(CreateApplicationRequest request)
        {
            var response = await _webService.CreateApplication(request);
            SaveRequestLog(request, response);

            return response;
        }
        /// <summary>
        /// PLACEHOLDER: Save log of webservice input/output.
        /// </summary>
        /// <remarks>
        /// Make sure this block is threadsafe.  It should have it's own data access resource & db transaction.
        /// </remarks>
        private void SaveRequestLog(CreateApplicationRequest request, CreateApplicationResponse response)
        {
            
        }

        /// <summary>
        /// PLACEHOLDER: Save assigned UID to data store
        /// </summary>
        /// <remarks>
        /// Make sure this block is threadsafe.  It should have it's own data access resource & db transaction.
        /// </remarks>
        private void SaveAssignedUid(CreateApplicationRequest request, string universityId)
        {
            
        }
    }
}