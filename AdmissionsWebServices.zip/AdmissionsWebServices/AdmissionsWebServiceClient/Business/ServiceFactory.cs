﻿using AdmissionsWebServiceClient.Client;

namespace AdmissionsWebServiceClient.Business
{
    public class ServiceFactory
    {
        public static ISendApplicationService GetDefault(IWebServiceClient client)
        {
            return new SendApplicationService(client);
        }
    }
}