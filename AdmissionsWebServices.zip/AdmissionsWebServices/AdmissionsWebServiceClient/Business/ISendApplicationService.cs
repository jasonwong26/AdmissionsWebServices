﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AdmissionsWebServiceClient.Models;

namespace AdmissionsWebServiceClient.Business
{
    public interface ISendApplicationService
    {
        Task<CreateApplicationResponse> SendApplication(CreateApplicationRequest application);
        Task<ICollection<Tuple<CreateApplicationRequest, CreateApplicationResponse>>> SendApplications(ICollection<CreateApplicationRequest> applications);
    }
}