﻿using System.Configuration;

namespace AdmissionsWebServiceClient.Utility
{
    internal static class Constants
    {
        public static class WebService
        {
            private const string ENDPOINT_CONFIG_CREDS = "WebService_Credentials";
            private const string DEFAULT_CREDENTIALS = "";
            public static string Credentials => ConfigurationManager.AppSettings[ENDPOINT_CONFIG_CREDS] ?? DEFAULT_CREDENTIALS;

            public static class CreateApplication
            {
                private const string ENDPOINT_CONFIG_KEY = "CreateApplication_Endpoint";
                private const string DEFAULT_ENDPOINT = "https://test.api.sa.it.ucla.edu/StudentServicesWeb2/restservice/admit/post";

                public static string Endpoint => ConfigurationManager.AppSettings[ENDPOINT_CONFIG_KEY] ?? DEFAULT_ENDPOINT;
            }
        }
    }
}