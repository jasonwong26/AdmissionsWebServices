﻿using System.Threading.Tasks;
using AdmissionsWebServiceClient.Models;

namespace AdmissionsWebServiceClient.Client
{
    public interface IWebServiceClient
    {
        string CreateApplicationEndpoint { get; }
        
        Task<CreateApplicationResponse> CreateApplication(CreateApplicationRequest application);
    }
}