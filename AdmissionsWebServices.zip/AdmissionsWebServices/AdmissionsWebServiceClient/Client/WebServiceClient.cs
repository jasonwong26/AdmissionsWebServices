﻿using AdmissionsWebServiceClient.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System.IO;
using System.Net;
using System.Threading.Tasks;

namespace AdmissionsWebServiceClient.Client
{
    internal class WebServiceClient : IWebServiceClient
    {
        private readonly string _createApplicationEndpoint;
        private readonly string _credentials;

        public WebServiceClient(string createEndpoint, string credentials)
        {
            _createApplicationEndpoint = createEndpoint;
            _credentials = credentials;
        }

        public string CreateApplicationEndpoint => _createApplicationEndpoint;

        public async Task<CreateApplicationResponse> CreateApplication(CreateApplicationRequest application)
        {
            var formattedInput = FormatInput(application);
            application.Json = SerializeToJson(formattedInput);
            var request = BuildPostJsonRequest(_createApplicationEndpoint, _credentials, application.Json);
            var response = await SendCreateApplication(request);

            return response;
        }
        /// <summary>
        /// converts typed object to untyped object in format matching request by Main Campus
        /// </summary>
        internal static dynamic FormatInput(CreateApplicationRequest app)
        {
            const string dateFormat = "yyyy-MM-ddTHH:mm:ss";
            const string currencyFormat = "0.##";

            return new
            {
                CareerCode = app.CareerCode ?? "",
                CollegeCode = app.CollegeCode ?? "",
                MajorCode = app.MajorCode ?? "",
                DegreeCode = app.DegreeCode ?? "",
                TermCode = app.TermCode ?? "",
                BatchId = app.BatchId ?? "",

                ApplicationDate = app.ApplicationDate.ToString(dateFormat),

                Ssn = app.Ssn ?? "",

                LascAccountNum = app.LascAccountNum ?? "",

                ApplicationType = app.ApplicationType ?? "",

                LastName = app.LastName ?? "",
                FirstName = app.FirstName ?? "",
                MiddleName = app.MiddleName ?? "",
                Suffix = app.Suffix ?? "",

                CurrentStreet1 = app.CurrentStreet1 ?? "",
                CurrentStreet2 = app.CurrentStreet2 ?? "",
                CurrentCity = app.CurrentCity ?? "",
                CurrentState = app.CurrentState ?? "",
                CurrentZipCode = app.CurrentZipCode ?? "",
                CurrentCountry = app.CurrentCountry ?? "",
                CurrentAddressEndDate = app.CurrentAddressEndDate?.ToString(dateFormat) ?? "",
                CurrentDayPhone = app.CurrentDayPhone ?? "",
                CurrentEvePhone = app.CurrentEvePhone ?? "",

                PermanentStreet1 = app.PermanentStreet1 ?? "",
                PermanentStreet2 = app.PermanentStreet2 ?? "",
                PermanentCity = app.PermanentCity ?? "",
                PermanentState = app.PermanentState ?? "",
                PermanentZipCode = app.PermanentZipCode ?? "",
                PermanentCountry = app.PermanentCountry ?? "",
                PermanentDayPhone = app.PermanentDayPhone ?? "",
                PermanentStateOfResidency = app.PermanentStateOfResidency ?? "",

                PrimaryEmail = app.PrimaryEmail ?? "",
                HighestDegree = app.HighestDegree ?? "",

                BirthDate = app.BirthDate?.ToString(dateFormat) ?? "",
                BirthCity = app.BirthCity ?? "",
                BirthCountry = app.BirthCountry ?? "",
                BirthPlace = app.BirthPlace ?? "",
                Gender = app.Gender ?? "",

                CountryOfCitizenship = app.CountryOfCitizenship ?? "",
                CitizenshipType = app.CitizenshipType ?? "",
                ResidencyCode = app.ResidencyCode ?? "",

                EarlyDecision = app.EarlyDecision?.ToString().ToLowerInvariant() ?? "",
                EpsteinProgram = app.EpsteinProgram?.ToString().ToLowerInvariant() ?? "",

                TribeMember = app.TribeMember?.ToString().ToLowerInvariant() ?? "",
                TribeName = app.TribeName ?? "",
                HispanicFlag = app.HispanicFlag?.ToString().ToLowerInvariant() ?? "",
                Ethnicity1 = app.Ethnicity1 ?? "",
                Ethnicity2 = app.Ethnicity2 ?? "",
                Ethnicity3 = app.Ethnicity3 ?? "",

                VeteranStatus = app.VeteranStatus ?? "",
                Disability = app.Disability ?? "",

                ApplicationFeeReceivedDate = app.ApplicationFeeReceivedDate?.ToString(dateFormat) ?? "",
                ApplicationFeeWaived = app.ApplicationFeeWaived?.ToString().ToLowerInvariant() ?? "",
                ApplicationFee = app.ApplicationFee?.ToString(currencyFormat) ?? "",
                CreditCardFee1 = app.CreditCardFee1?.ToString(currencyFormat) ?? "",

                ReleaseFlag = app.ReleaseFlag?.ToString().ToLowerInvariant() ?? "",

                CommunityCollegeCode = app.CommunityCollegeCode ?? "",
                CommunityCollegeExperience = app.CommunityCollegeExperience ?? "",
                CommunityCollegeStartDate = app.CommunityCollegeStartDate?.ToString(dateFormat) ?? "",

                GenderExpression = app.GenderExpression ?? "",
                GenderIdentity = app.GenderIdentity ?? "",
                SexualOrientationCode = app.SexualOrientationCode ?? "",
                SexualOrientation = app.SexualOrientation ?? ""
            };
        }
        internal static string SerializeToJson<T>(T input)
        {
            var settings = new JsonSerializerSettings
            {
                ContractResolver = new CamelCasePropertyNamesContractResolver()
            };
            return JsonConvert.SerializeObject(input, settings);
        }
        internal static WebRequest BuildPostJsonRequest(string url, string credentials, string json)
        {
            var request = WebRequest.Create(url);
            request.Headers.Add("credentials", credentials);
            request.Method = "POST";
            request.ContentType = "application/json";
            using (var requestWriter = new StreamWriter(request.GetRequestStream()))
            {
                requestWriter.Write(json);
            }

            return request;
        }
        private static async Task<CreateApplicationResponse> SendCreateApplication(WebRequest request)
        {
            try
            {
                using (var response = await request.GetResponseAsync())
                using (var responseReader = new StreamReader(response.GetResponseStream()))
                {
                    var jsonOutput = responseReader.ReadToEnd();
                    var output = JsonConvert.DeserializeObject<CreateApplicationResponse>(jsonOutput);
                    output.ResponseCode = ((HttpWebResponse)response).StatusCode;

                    output.Json = jsonOutput;

                    return output;
                }
            }
            catch (WebException ex)
            {
                var responseCode = ((HttpWebResponse)ex.Response).StatusCode;

                try
                {
                    using (var responseReader = new StreamReader(ex.Response.GetResponseStream()))
                    {
                        var jsonOutput = responseReader.ReadToEnd();
                        var output = JsonConvert.DeserializeObject<CreateApplicationResponse>(jsonOutput);
                        output.ResponseCode = responseCode;

                        output.Json = jsonOutput;

                        return output;
                    }
                }
                catch (JsonSerializationException jex)
                {
                    return new CreateApplicationResponse
                    {
                        ResponseCode = responseCode,
                        Message = ex.Message,
                        Errors = new[]
                        {
                            new CreateApplicationResponseError
                            {
                                Code = "",
                                Message = jex.Message
                            }
                        },
                        Json = jex.Message
                    };
                }
            }
        }
    }
}