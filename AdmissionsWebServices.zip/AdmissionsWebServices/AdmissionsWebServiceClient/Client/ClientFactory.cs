﻿using AdmissionsWebServiceClient.Utility;

namespace AdmissionsWebServiceClient.Client
{
    public static class ClientFactory
    {
        public static IWebServiceClient GetDefault()
        {
            var createEndpoint = Constants.WebService.CreateApplication.Endpoint;
            var credentials = Constants.WebService.Credentials;

            return GetDefault(createEndpoint, credentials);
        }

        public static IWebServiceClient GetDefault(string createEndpoint, string credentials)
        {
            return new WebServiceClient(createEndpoint, credentials);
        }
    }
}