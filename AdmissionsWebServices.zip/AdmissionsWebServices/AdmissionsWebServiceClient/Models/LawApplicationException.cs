﻿using System;

namespace AdmissionsWebServiceClient.Models
{
    internal class LawApplicationException : Exception
    {
        public LawApplicationException(string message) : base(message)
        {
        }

        public LawApplicationException(string message, Exception innerException) : base(message, innerException)
        {

        }

        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string LascAccountNum { get; set; }
    }
}