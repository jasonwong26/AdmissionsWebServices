﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Net;

namespace AdmissionsWebServiceClient.Models
{
    public class CreateApplicationRequest
    {
        public CreateApplicationRequest()
        {
            CareerCode = "L";
            CollegeCode = "LW";
        }

        public static CreateApplicationRequest CreateJdApplicationRequest()
        {
            return new CreateApplicationRequest
            {
                MajorCode = "501",
                DegreeCode = "JD"
            };
        }

        public static CreateApplicationRequest CreateLlmApplicationRequest()
        {
            return new CreateApplicationRequest
            {
                MajorCode = "50B",
                DegreeCode = "LLM"
            };
        }

        [Required]
        public string CareerCode { get; set; }
        [Required]
        public string CollegeCode { get; set; }
        [Required]
        public string MajorCode { get; set; }
        [Required]
        public string DegreeCode { get; set; }
        [Required]
        public string TermCode { get; set; }

        public string BatchId { get; set; }

        [Required]
        public DateTime ApplicationDate { get; set; }

        [MinLength(9), MaxLength(9)]
        public string Ssn { get; set; }

        [MinLength(9), MaxLength(9)]
        public string LascAccountNum { get; set; }

        [MinLength(9), MaxLength(9)]
        public string ApplicationType { get; set; }

        [Required]
        public string LastName { get; set; }
        [Required]
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string Suffix { get; set; }

        public string CurrentStreet1 { get; set; }
        public string CurrentStreet2 { get; set; }
        public string CurrentCity { get; set; }
        public string CurrentState { get; set; }
        public string CurrentZipCode { get; set; }
        public string CurrentCountry { get; set; }
        public DateTime? CurrentAddressEndDate { get; set; }
        public string CurrentDayPhone { get; set; }
        public string CurrentEvePhone { get; set; }

        [Required]
        public string PermanentStreet1 { get; set; }
        public string PermanentStreet2 { get; set; }
        [Required]
        public string PermanentCity { get; set; }
        [Required]
        public string PermanentState { get; set; }
        [Required]
        public string PermanentZipCode { get; set; }
        [Required]
        public string PermanentCountry { get; set; }
        public string PermanentDayPhone { get; set; }
        public string PermanentStateOfResidency { get; set; }

        [Required]
        public string PrimaryEmail { get; set; }
        public string HighestDegree { get; set; }

        [Required]
        public DateTime? BirthDate { get; set; }
        public string BirthCity { get; set; }
        public string BirthCountry { get; set; }
        public string BirthPlace { get; set; }
        [Required, MinLength(1), MaxLength(1)]
        public string Gender { get; set; }

        public string CountryOfCitizenship { get; set; }
        public string CitizenshipType { get; set; }
        public string ResidencyCode { get; set; }

        public bool? EarlyDecision { get; set; }
        public bool? EpsteinProgram { get; set; }

        public bool? TribeMember { get; set; }
        public string TribeName { get; set; }
        public bool? HispanicFlag { get; set; }
        public string Ethnicity1 { get; set; }
        public string Ethnicity2 { get; set; }
        public string Ethnicity3 { get; set; }

        public string VeteranStatus { get; set; }
        public string Disability { get; set; }

        public DateTime? ApplicationFeeReceivedDate { get; set; }
        public bool? ApplicationFeeWaived { get; set; }
        public decimal? ApplicationFee { get; set; }
        public decimal? CreditCardFee1 { get; set; }

        public bool? ReleaseFlag { get; set; }

        public string CommunityCollegeCode { get; set; }
        public string CommunityCollegeExperience { get; set; }
        public DateTime? CommunityCollegeStartDate { get; set; }

        public string GenderExpression { get; set; }
        public string GenderIdentity { get; set; }
        public string SexualOrientationCode { get; set; }
        public string SexualOrientation { get; set; }

        public string Json { get; set; }
    }

    public class CreateApplicationResponse
    {
        public CreateApplicationResponse()
        {
            Errors = new List<CreateApplicationResponseError>();
        }

        [Required]
        public HttpStatusCode ResponseCode { get; set; }
        [Required]
        public string Message { get; set; }

        public string UniversityId
        {
            get => _universityId;
            set => _universityId = !string.IsNullOrEmpty(value) ? value : null;
        }
        private string _universityId;

        public string BatchId
        {
            get => _batchId;
            set => _batchId = !string.IsNullOrEmpty(value) ? value : null;
        }
        private string _batchId;

        public ICollection<CreateApplicationResponseError> Errors { get; set; }

        public string Json { get; set; }

        public bool Successful => ResponseCode == HttpStatusCode.OK;
    }
    public class CreateApplicationResponseError
    {
        [Required]
        public string Code { get; set; }
        [Required]
        public string Message { get; set; }
    }
}