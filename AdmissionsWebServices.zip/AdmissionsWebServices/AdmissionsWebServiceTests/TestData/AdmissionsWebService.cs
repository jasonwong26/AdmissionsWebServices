﻿using System;
using System.Collections.Generic;
using AdmissionsWebServiceClient.Models;

namespace AdmissionsWebServiceTests.TestData
{
    internal static class AdmissionsWebService
    {
        public static CreateApplicationRequest SerializationTestsModel
        {
            get
            {
                var request = new CreateApplicationRequest
                {
                    TermCode = "18F",
                    ApplicationDate = new DateTime(2017, 9, 5),
                    Ssn = new string('9', 9),
                    LascAccountNum = "L37123231",
                    ApplicationType = "A1",
                    MajorCode = "501",
                    DegreeCode = "JD",

                    FirstName = "Erin",
                    LastName = "McLaughlin",
                    MiddleName = "Maureen",

                    CurrentStreet1 = "514 Edgewood Place",
                    CurrentCity = "Ithaca",
                    CurrentState = "NY",
                    CurrentZipCode = "14850",
                    CurrentCountry = "USA",
                    CurrentAddressEndDate = new DateTime(2018, 5, 25),
                    CurrentDayPhone = "7204385380",
                    CurrentEvePhone = "7204385380",

                    PermanentStreet1 = "1611 Mountain Drive",
                    PermanentCity = "Longmont",
                    PermanentState = "CO",
                    PermanentZipCode = "80503",
                    PermanentCountry = "USA",
                    PermanentDayPhone = "3034850885",
                    PermanentStateOfResidency = "CO",

                    PrimaryEmail = "EMM297@CORNELL.EDU",
                    HighestDegree = "Bachelors",

                    Gender = "F",
                    BirthDate = new DateTime(1950, 1, 1),
                    BirthCity = "Dayton",
                    BirthCountry = "USA",
                    BirthPlace = "Dayton, OH, USA",

                    CountryOfCitizenship = "USA",
                    CitizenshipType = "US Citizen",
                    ResidencyCode = "Non-Resident",

                    HispanicFlag = false,


                    EarlyDecision = null,
                    EpsteinProgram = false,

                    TribeMember = false,
                    Ethnicity1 = "European/European descent",

                    VeteranStatus = "None of the above",

                    ApplicationFeeReceivedDate = new DateTime(2017, 9, 5),
                    ApplicationFeeWaived = false,
                    ApplicationFee = 75,
                    CreditCardFee1 = 3.75m,

                    ReleaseFlag = true,

                };

                return request;
            }
        }

        public static CreateApplicationRequest SingleSubmissionModel
        {
            get
            {
                var request = new CreateApplicationRequest
                {
                    TermCode = "18F",
                    ApplicationDate = new DateTime(2018, 6, 26),
                    Ssn = "111111111",
                    LascAccountNum = "L36015623",
                    ApplicationType = "A2",
                    MajorCode = "501",
                    DegreeCode = "JD",

                    FirstName = "Enriko",
                    LastName = "Alfaro",
                    MiddleName = "G",

                    CurrentStreet1 = "6345 Cotton Ave.",
                    CurrentCity = "Newark",
                    CurrentState = "CA",
                    CurrentZipCode = "94560",
                    CurrentCountry = "USA",
                    CurrentAddressEndDate = new DateTime(2018, 8, 20),
                    CurrentDayPhone = "5102489082",
                    CurrentEvePhone = "",

                    PermanentStreet1 = "6345 Cotton Ave.",
                    PermanentCity = "Newark",
                    PermanentState = "CA",
                    PermanentZipCode = "94560",
                    PermanentCountry = "USA",
                    PermanentDayPhone = "5102489082",
                    PermanentStateOfResidency = "CA",

                    PrimaryEmail = "ealfaro@scu.edu",
                    HighestDegree = "Bachelors",

                    Gender = "M",
                    BirthDate = new DateTime(1950, 1, 1),
                    BirthCity = "Hayward",
                    BirthCountry = "USA",
                    BirthPlace = "Hayward,CA,USA",

                    CountryOfCitizenship = "USA",
                    CitizenshipType = "US Citizen",
                    ResidencyCode = "Resident",

                    HispanicFlag = true,


                    EarlyDecision = false,
                    EpsteinProgram = false,

                    TribeMember = false,
                    Ethnicity1 = "Latin American/Latino",
                    Ethnicity2 = "Mexican/Mexican American/Chicano",
                    Ethnicity3 = "Black/African American",

                    VeteranStatus = "None of the above",

                    ApplicationFeeReceivedDate = new DateTime(2018, 6, 26),
                    ApplicationFeeWaived = false,
                    ApplicationFee = 75,
                    CreditCardFee1 = 3.75m,

                    ReleaseFlag = true
                };

                return request;
            }
        }

        public static ICollection<CreateApplicationRequest> BatchSubmissionModel
        {
            get
            {
                return new List<CreateApplicationRequest>
                {
                    new CreateApplicationRequest
                    {
                        TermCode = "18F",
                        ApplicationDate = new DateTime(2018, 6, 26),
                        Ssn = new string('2', 9),
                        LascAccountNum = "L37004250",
                        ApplicationType = "A2",
                        MajorCode = "501",
                        DegreeCode = "JD",

                        FirstName = "Laura",
                        LastName = "Moedano",
                        MiddleName = "",

                        CurrentStreet1 = "4700 W. Guadalupe St., A333",
                        CurrentCity = "Austin",
                        CurrentState = "TX",
                        CurrentZipCode = "78751",
                        CurrentCountry = "USA",
                        CurrentAddressEndDate = new DateTime(2018, 12, 30),
                        CurrentDayPhone = "7607918990",
                        CurrentEvePhone = "7607918990",

                        PermanentStreet1 = "2177 S. 29th Ave.",
                        PermanentCity = "Yuma",
                        PermanentState = "AZ",
                        PermanentZipCode = "85364",
                        PermanentCountry = "USA",
                        PermanentDayPhone = "7607918990",
                        PermanentStateOfResidency = "CA",

                        PrimaryEmail = "laura.moedano@yahoo.com",
                        HighestDegree = "Masters",

                        Gender = "F",
                        BirthDate = new DateTime(1950, 1, 1),
                        BirthCity = "Yuma",
                        BirthCountry = "USA",
                        BirthPlace = "Yuma,AZ,USA",

                        CountryOfCitizenship = "USA",
                        CitizenshipType = "US Citizen",
                        ResidencyCode = "Non-Resident",

                        HispanicFlag = true,

                        EarlyDecision = false,
                        EpsteinProgram = false,

                        TribeMember = false,
                        Ethnicity1 = "Mexican/Mexican American/Chicano",

                        VeteranStatus = "None of the above",

                        ApplicationFeeReceivedDate = new DateTime(2018, 6, 26),
                        ApplicationFeeWaived = false,
                        ApplicationFee = 75,
                        CreditCardFee1 = 3.75m,

                        ReleaseFlag = true
                    },
                    new CreateApplicationRequest
                    {
                        TermCode = "18F",
                        ApplicationDate = new DateTime(2018, 6, 26),
                        Ssn = new string('3', 9),
                        LascAccountNum = "L37007785",
                        ApplicationType = "A2",
                        MajorCode = "501",
                        DegreeCode = "JD",

                        FirstName = "Anahita",
                        LastName = "Anvari",
                        MiddleName = "",

                        CurrentStreet1 = "218 W South Street",
                        CurrentCity = "Carlisle",
                        CurrentState = "PA",
                        CurrentZipCode = "17013",
                        CurrentCountry = "USA",
                        CurrentAddressEndDate = new DateTime(2018, 8, 30),
                        CurrentDayPhone = "7144213411",
                        CurrentEvePhone = "",

                        PermanentStreet1 = "10792 Center Drive",
                        PermanentCity = "villa park",
                        PermanentState = "CA",
                        PermanentZipCode = "92861",
                        PermanentCountry = "USA",
                        PermanentDayPhone = "7144213411",
                        PermanentStateOfResidency = "CA",

                        PrimaryEmail = "ANVARI.ANAHITA@GMAIL.COM",
                        HighestDegree = "Masters",

                        Gender = "F",
                        BirthDate = new DateTime(1950, 1, 1),
                        BirthCity = "Los Angeles",
                        BirthCountry = "USA",
                        BirthPlace = "Los Angeles,CA,USA",

                        CountryOfCitizenship = "USA",
                        CitizenshipType = "US Citizen",
                        ResidencyCode = "Resident",

                        HispanicFlag = false,

                        EarlyDecision = false,
                        EpsteinProgram = false,

                        TribeMember = false,
                        Ethnicity1 = "Middle Eastern or North African",

                        VeteranStatus = "None of the above",

                        ApplicationFeeReceivedDate = new DateTime(2018, 6, 25),
                        ApplicationFeeWaived = false,
                        ApplicationFee = 75,
                        CreditCardFee1 = 3.75m,

                        ReleaseFlag = true
                    },
                    new CreateApplicationRequest
                    {
                        TermCode = "18F",
                        ApplicationDate = new DateTime(2018, 6, 26),
                        Ssn = new string('4', 9),
                        LascAccountNum = "L34028915",
                        ApplicationType = "A2",
                        MajorCode = "501",
                        DegreeCode = "JD",

                        FirstName = "Yilong",
                        LastName = "Hao",
                        MiddleName = "",

                        CurrentStreet1 = "1175 Lake Blvd",
                        CurrentCity = "Davis",
                        CurrentState = "CA",
                        CurrentZipCode = "95616",
                        CurrentCountry = "USA",
                        CurrentAddressEndDate = new DateTime(2018, 8, 31),
                        CurrentDayPhone = "4083385902",
                        CurrentEvePhone = "4083385902",

                        PermanentStreet1 = "2148 Port Way",
                        PermanentCity = "San Jose",
                        PermanentState = "CA",
                        PermanentZipCode = "95133",
                        PermanentCountry = "USA",
                        PermanentDayPhone = "4083385902",
                        PermanentStateOfResidency = "CA",

                        PrimaryEmail = "YLHAO@UCDAVIS.EDU",
                        HighestDegree = "Bachelors",

                        Gender = "F",
                        BirthDate = new DateTime(1950, 1, 1),
                        BirthCity = "Beijing",
                        BirthCountry = "China",
                        BirthPlace = "Beijing,China",

                        CountryOfCitizenship = "USA",
                        CitizenshipType = "US Citizen",
                        ResidencyCode = "Resident",

                        HispanicFlag = false,

                        EarlyDecision = false,
                        EpsteinProgram = false,

                        TribeMember = false,
                        Ethnicity1 = "Asian Indian",
                        Ethnicity2 = "Filipino/Filipino American",

                        VeteranStatus = "None of the above",

                        ApplicationFeeReceivedDate = new DateTime(2018, 6, 26),
                        ApplicationFeeWaived = false,
                        ApplicationFee = 75,
                        CreditCardFee1 = 3.75m,

                        ReleaseFlag = true
                    },
                    new CreateApplicationRequest
                    {
                        TermCode = "18F",
                        ApplicationDate = new DateTime(2018, 6, 26),
                        Ssn = new string('5', 9),
                        LascAccountNum = "L33024588",
                        ApplicationType = "A2",
                        MajorCode = "501",
                        DegreeCode = "JD",

                        FirstName = "Kevin",
                        LastName = "Cacabelos",
                        MiddleName = "Dacuag",

                        CurrentStreet1 = "1947 Dwight 3B",
                        CurrentCity = "Berkeley",
                        CurrentState = "CA",
                        CurrentZipCode = "94704",
                        CurrentCountry = "USA",
                        CurrentAddressEndDate = new DateTime(2018, 7, 31),
                        CurrentDayPhone = "2069316721",
                        CurrentEvePhone = "",

                        PermanentStreet1 = "5709 S. Victor St.",
                        PermanentCity = "Seattle",
                        PermanentState = "WA",
                        PermanentZipCode = "98178",
                        PermanentCountry = "USA",
                        PermanentDayPhone = "2069316721",
                        PermanentStateOfResidency = "CA",

                        PrimaryEmail = "KCACABELOS@GMAIL.COM",
                        HighestDegree = "Masters",

                        Gender = "M",
                        BirthDate = new DateTime(1950, 1, 1),
                        BirthCity = "Seattle",
                        BirthCountry = "USA",
                        BirthPlace = "Seattle,WA,USA",

                        CountryOfCitizenship = "USA",
                        CitizenshipType = "US Citizen",
                        ResidencyCode = "Non-Resident",

                        HispanicFlag = false,

                        EarlyDecision = false,
                        EpsteinProgram = false,

                        TribeMember = false,
                        Ethnicity1 = "Filipino/Filipino American",

                        VeteranStatus = "None of the above",

                        ApplicationFeeReceivedDate = new DateTime(2018, 6, 25),
                        ApplicationFeeWaived = false,
                        ApplicationFee = 75,
                        CreditCardFee1 = 3.75m,

                        ReleaseFlag = true
                    },
                    new CreateApplicationRequest
                    {
                        TermCode = "18F",
                        ApplicationDate = new DateTime(2018, 6, 26),
                        Ssn = new string('6', 9),
                        LascAccountNum = "L35009365",
                        ApplicationType = "A3",
                        MajorCode = "501",
                        DegreeCode = "JD",

                        FirstName = "Shawn",
                        LastName = "Quigg",
                        MiddleName = "P",

                        CurrentStreet1 = "113 McGill St.",
                        CurrentCity = "Toronto",
                        CurrentState = "ON",
                        CurrentZipCode = "M5B1H5",
                        CurrentCountry = "Canada",
                        CurrentAddressEndDate = new DateTime(2018, 8, 26),
                        CurrentDayPhone = "2263502877",
                        CurrentEvePhone = "2263502877",

                        PermanentStreet1 = "1181 Rankin Ave.",
                        PermanentCity = "Windsor",
                        PermanentState = "ON",
                        PermanentZipCode = "N9B2S4",
                        PermanentCountry = "Canada",
                        PermanentDayPhone = "2263502877",
                        PermanentStateOfResidency = "",

                        PrimaryEmail = "spquigg@gmail.com",
                        HighestDegree = "Bachelors",

                        Gender = "M",
                        BirthDate = new DateTime(1950, 1, 1),
                        BirthCity = "London",
                        BirthCountry = "Canada",
                        BirthPlace = "London,ON,Canada",

                        CountryOfCitizenship = "Canada",
                        CitizenshipType = "Other",
                        ResidencyCode = "Non-Resident",

                        HispanicFlag = false,

                        EarlyDecision = false,
                        EpsteinProgram = false,

                        TribeMember = false,
                        Ethnicity1 = "Did not Indicate",

                        VeteranStatus = "None of the above",

                        ApplicationFeeReceivedDate = new DateTime(2018, 6, 26),
                        ApplicationFeeWaived = false,
                        ApplicationFee = 75,
                        CreditCardFee1 = 3.75m,

                        ReleaseFlag = true
                    }
                };
            }
        }
    }
}