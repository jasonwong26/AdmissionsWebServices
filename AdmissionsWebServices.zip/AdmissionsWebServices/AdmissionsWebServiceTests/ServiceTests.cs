﻿using System.Linq;
using AdmissionsWebServiceClient.Business;
using AdmissionsWebServiceClient.Client;
using AdmissionsWebServiceTests.TestData;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Threading.Tasks;

namespace AdmissionsWebServiceTests
{
    [TestClass]
    public class ServiceTests
    {
        private IWebServiceClient _client;
        private ISendApplicationService _service;

        [TestInitialize]
        public void Initialize()
        {
            _client = ClientFactory.GetDefault();
            _service = ServiceFactory.GetDefault(_client);
        }

        [TestMethod]
        public async Task Service_SendApplication()
        {
            var request = AdmissionsWebService.SingleSubmissionModel;
            var result = await _service.SendApplication(request);

            Assert.IsNotNull(result);
            Assert.IsFalse(result.Successful);
        }

        [TestMethod]
        public async Task Service_SendApplications()
        {
            var applications = AdmissionsWebService.BatchSubmissionModel;
            var results = await _service.SendApplications(applications);

            Assert.IsNotNull(results);
            Assert.AreEqual(applications.Count, results.Count);
            Assert.AreEqual(0, results.Count(r => r.Item2.Successful));
        }
    }
}