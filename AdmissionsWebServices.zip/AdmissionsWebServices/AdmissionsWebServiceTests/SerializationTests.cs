﻿using System.Linq;
using System.Net;
using AdmissionsWebServiceClient.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft.Json;
using AdmissionsWebServiceClient.Client;

namespace AdmissionsWebServiceTests
{
    [TestClass]
    public class SerializationTests
    {
        [TestMethod]
        public void WebService_FormatInput()
        {
            var request = TestData.AdmissionsWebService.SerializationTestsModel;
            var input = WebServiceClient.FormatInput(request);

            var propertyInfo = input.GetType().GetProperty("LascAccountNum");
            var value = propertyInfo.GetValue(input, null);
            Assert.AreEqual("L37123231", value);

            propertyInfo = input.GetType().GetProperty("CurrentAddressEndDate");
            value = propertyInfo.GetValue(input, null);
            Assert.AreEqual("2018-05-25T00:00:00", value);

            propertyInfo = input.GetType().GetProperty("HispanicFlag");
            value = propertyInfo.GetValue(input, null);
            Assert.AreEqual("false", value);

            propertyInfo = input.GetType().GetProperty("CommunityCollegeStartDate");
            value = propertyInfo.GetValue(input, null);
            Assert.AreEqual("", value);

            propertyInfo = input.GetType().GetProperty("EarlyDecision");
            value = propertyInfo.GetValue(input, null);
            Assert.AreEqual("", value);

            propertyInfo = input.GetType().GetProperty("ApplicationFee");
            value = propertyInfo.GetValue(input, null);
            Assert.AreEqual("75", value);

            propertyInfo = input.GetType().GetProperty("CreditCardFee1");
            value = propertyInfo.GetValue(input, null);
            Assert.AreEqual("3.75", value);
        }

        [TestMethod]
        public void WebService_DeserializeCreateResponse_1()
        {
            var input = "{\"batchId\":\"\",\"errors\":[{\"code\":\"\",\"message\":\"PermanentEmail should not be null\"}],\"message\":\"Invalid Input\",\"universityId\":\"\"}";

            var response = JsonConvert.DeserializeObject<CreateApplicationResponse>(input);
            response.ResponseCode = HttpStatusCode.BadRequest;

            Assert.IsFalse(response.Successful);
            Assert.IsNull(response.UniversityId);
            Assert.IsNull(response.BatchId);
            Assert.AreEqual("Invalid Input", response.Message);

            Assert.AreEqual(1, response.Errors.Count);
            Assert.AreEqual("PermanentEmail should not be null", response.Errors.First().Message);
        }

        [TestMethod]
        public void WebService_DeserializeCreateResponse_2()
        {
            var input = "{\"batchId\":\"\",\"errors\":[{\"code\":\"I0018\",\"message\":\"Birth state code not found\"},{\"code\":\"I0005\",\"message\":\"Invalid military service status\"},{\"code\":\"I0002\",\"message\":\"Invalid IPED\"},{\"code\":\"IDIAG\",\"message\":\"LA720\"}],\"message\":\"Created Successfully\",\"universityId\":\"903788308\"}";

            var response = JsonConvert.DeserializeObject<CreateApplicationResponse>(input);
            response.ResponseCode = HttpStatusCode.OK;

            Assert.IsTrue(response.Successful);
            Assert.AreEqual("903788308", response.UniversityId);
            Assert.IsNull(response.BatchId);
            Assert.AreEqual("Created Successfully", response.Message);

            Assert.AreEqual(4, response.Errors.Count);
            Assert.AreEqual("Birth state code not found", response.Errors.First().Message);
        }
    }
}